import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
# Degree Centrality
#########################flight_haults###########################
data=pd.read_csv("G:\\practical data science\\Assignments\\Network Analytics\\Network Analytics Datasets\\flight_hault.csv")
data =data.iloc[:,1:10]
g = nx.Graph()
FG= nx.from_pandas_edgelist(data,source='Goroka',target='Papua New Guinea',edge_attr=True)
FG.nodes()
FG.edges()
pos = nx.spring_layout(data,k=0.15)
nx.draw_networkx(g,pos,node_size = 25, node_color = 'blue')
# closeness centrality
closeness = nx.closeness_centrality(FG)
print(closeness)
#betweness Centrality
b = nx.betweenness_centrality(FG)
print(b)


#######################connecting_routes#########################
data1=pd.read_csv("G:\\practical data science\\Assignments\\Network Analytics\\Network Analytics Datasets\\connecting_routes.csv")
data1=data1.iloc[:,1:10]
g1= nx.Graph()
CG= nx.from_pandas_edgelist(data1,source='AER',target='KZN',edge_attr=True)

CG.nodes()
CG.edges()



pos = nx.spring_layout(data1,k=0.15)
nx.draw_networkx(g1,pos,node_size = 25, node_color = 'blue')

# closeness centrality
closeness = nx.closeness_centrality(CG)
print(closeness)
#betweness Centrality
b= nx.betweenness_centrality(CG)
print(b)



