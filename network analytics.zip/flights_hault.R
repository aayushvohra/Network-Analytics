#install.pacakages("igraph")
library(igraph)
?igraph
#########flights haults#########
#Load the adjacency matrix from the csv file
flight_hault  <- read.csv("G:/practical data science/Assignments/Network Analytics/Network Analytics Datasets/flight_hault.csv")
head(flight_hault)
connecting_routes <-read.csv("G:/practical data science/Assignments/Network Analytics/Network Analytics Datasets/connecting_routes.csv")
head(connecting_routes)
# create a newtwork using adjacency matrix
?graph.adjacency
# help file for the api graph.adjacency
flightNW <- graph.edgelist(as.matrix(connecting_routes [,c(3,5)]), directed =TRUE )
plot(flightNW)
undirected_graph(flightNW)
plot(flightNW)
betweenness(flightNW)
centralization.closeness(flightNW)
page.rank(flightNW)$vector
page.rank(flightNW)
