#install.packages("igraph")
library(igraph)
?igraph
g1 = graph(c(1,2,1,3,2,3,3,5), n = 5)
plot(g1)
g2 = graph(c(1,2, 1,3, 2,3, 3,5), n =5, directed = F)
plot(g2)
####################STAR GRAPH OF THREE MEDIA DATA(FACEBOOK,INSTAGRAM,LINKEDIN)############
###################STAR_FACEBOOK############################################################
star_facebook <- read.csv("G:/practical data science/Assignments/Network Analytics/Network Analytics Datasets/facebook.csv")
head(star_facebook)
star_facebookNW <- graph.adjacency(as.matrix(star_facebook), mode = "undirected")
plot(star_facebookNW)
###################STAR_INSTAGRAM############################################################
star_instagram <-read.csv("G:/practical data science/Assignments/Network Analytics/Network Analytics Datasets/instagram.csv")
head(star_instagram)
star_instagramNW <- graph.adjacency(as.matrix(star_instagram), mode="undirected")
plot(star_instagramNW)
###################STAR_LINKEDIN############################################################
star_linkedin <- read.csv("G:/practical data science/Assignments/Network Analytics/Network Analytics Datasets/linkedin.csv")
head(star_linkedin)
star_linkedinNW <- graph.adjacency(as.matrix(star_linkedin), mode = "undirected")
plot(star_linkedinNW)

####################CIRCLE  GRAPH OF THREE MEDIA DATA(FACEBOOK,INSTAGRAM,LINKEDIN)############
###################CIRCLE_FACEBOOK############################################################
circular_facebook <- read.csv("G:/practical data science/network analytics/Network_Analytics_Datasets/Circular.csv", header=TRUE)
head(circular_facebook)
circular_facebookNW <- graph.adjacency(as.matrix(circular_facebook), mode = "undirected", weighted = TRUE)
plot(circular_facebookNW)
###################CIRCLE_INSTAGRAM############################################################
circular_instagram <- read.csv("G:/practical data science/Assignments/Network Analytics/Network Analytics Datasets/instagram.csv")
head(circular_instagram)
circular_instagramNW <- graph.adjacency(as.matrix(circular_instagram), mode="undirected", weighted = TRUE)
plot(circular_instagramNW)
###################CIRCLE_LINKEDIN############################################################
circular_linkedin <- read.csv("G:/practical data science/Assignments/Network Analytics/Network Analytics Datasets/linkedin.csv")
head(circular_linkedin)
circular_linkedinNW <- graph.adjacency(as.matrix(circular_linkedin), mode = "undirected",weighted = TRUE)
plot(circular_linkedinNW)

